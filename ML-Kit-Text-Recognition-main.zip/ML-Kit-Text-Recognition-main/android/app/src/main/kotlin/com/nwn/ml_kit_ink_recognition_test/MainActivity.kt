package com.nwn.ml_kit_ink_recognition_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
